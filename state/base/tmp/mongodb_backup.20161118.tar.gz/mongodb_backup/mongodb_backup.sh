#!/bin/bash
# Author  : chinatree <chinatree2012@gmail.com>
# Date    : 2015-01-15
# Version : 1.0
# Works :

PATH="${HOME}/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
export PATH

# [global]
SCRIPT_PATH="$(cd "$(dirname "$0")"; pwd)"
SCRIPT_NAME="$(basename "$0")"
PROJECT_ROOT="$(cd "${SCRIPT_PATH}"; pwd)"
CONFIG_DIR="${PROJECT_ROOT}/etc"
CONFIG_FILE="${CONFIG_DIR}/config.ini"
PARA_NUM="$#"
PROC_PID="$$"

if test -f "${CONFIG_FILE}"
then
    . "${CONFIG_FILE}"
else
    echo "The file ${CONFIG_FILE} not exists, please check it and try again!"
    exit 1
fi

load_file "${COMMON_FILE}"
! test -d "${LOG_DIR}" && mkdir -p "${LOG_DIR}"
# Record Execute Log
echo "[${log_time_format}][${SCRIPT_NAME}] Parameters: $@" >> "${LOG_DIR}/execute.log"
parse_arguments $@
mkdir -p "${LOG_DIR}"

usage()
{
    echo -e "`get_color "Usage:" CYANBLUE` \
    \n    ./${SCRIPT_NAME} -C=etc/default.ini [-D|--debug] [-H|--help]"
    exit 2
}

parse_arguments() {
    for arg do
        case "$arg" in
            -C=*)
                account_file=$(echo "${arg}" | sed -e 's/^[^=]*=//')
                ;;
            -H|--help)
                usage
                ;;
            -D|--debug)
                set -x
                ;;
        esac
    done
}

do_dump()
{
    local host="${1}"
    local port="${2}"
    local user="${3}"
    local pass="${4}"
    local auth_db="${5}"
    local database="${6}"
    local collection="${7}"
    local storage_dir="${8}"
    local dump_para=''

    # must specify the database
    test -z "${database}" && display_error "You must specify the database, dump interrupt ..." && return 1
    test -z "${storage_dir}" && display_error "You must specify storage dir for ${database}, dump interrupt ..." && return 1

    test -n "${host}" && dump_para="${dump_para} --host ${host}"
    test -n "${port}" && dump_para="${dump_para} --port ${port}"
    test -n "${user}" && dump_para="${dump_para} -u ${user}"
    test -n "${pass}" && dump_para="${dump_para} -p ${pass}"
    test -n "${auth_db}" && dump_para="${dump_para} --authenticationDatabase ${auth_db}"
    dump_para="${dump_para} -d ${database}"
    test -n "${collection}" && dump_para="${dump_para} -c ${collection}"
    test -n "${storage_dir}" && dump_para="${dump_para} -o ${storage_dir}"

    echo "Mongodb dumping `get_color "${database}" PEACH` ..." >> "${log_file}"
    ${mongodump_bin} ${dump_para} >> "${log_file}" 2>&1
    get_exit_code $? 0 >> "${log_file}"

    return 0
}

do_tarball()
{
    local storage_dir="${1}"
    local database="${2}"
    local tarball_name="${3}"

    test ! -d "${storage_dir}/${database}" && display_error "The storage dir ${storage_dir} not exists, tarball interrupt ..." && return 1
    cd "${storage_dir}"
    echo "Tarball `get_color "${database}" PEACH` to ${database}-${file_time_format}.tgz ..." >> "${log_file}"
    tar cjpf "${tarball_name}" "${database}"
    get_exit_code $? 0 >> "${log_file}"

    # clean temp folder
    rm -rf "${storage_dir}/${database}"

    return 0
}

do_rsync()
{
    local storage_dir="${1}"
    local tarball_name="${2}"
    if [ "${rsync_anabled}" -eq 1 ] && [ -f "${storage_dir}/${tarball_name}" ];
    then
        echo -n "Rsync ${tarball_name} to `get_color "${rsync_user}@${rsync_host}:${rsync_remote_path}" PEACH` ..." >> "${log_file}"
        ${rsync_bin} -e "ssh -i ${rsync_key} -p ${rsync_port}" --bwlimit="${rsync_speed}" -a "${storage_dir}/${tarball_name}" "${rsync_user}"@"${rsync_host}":"${rsync_remote_path}"
        get_exit_code $? 0 >> "${log_file}"
    fi

    return 0
}

do_clean_backup(){
    local storage_dir="${1:-/tmp}"
    local key="${2:-None}"
    local suffix="${3:-None}"
    local keep_day="${4:-7}"
    local keey_unit="${5:-day}"

    if [ "${keey_unit}" == "mmin" ];
    then
        find "${storage_dir}" -type f -name "${key}*${suffix}" -mmin +"${keep_day}" -exec rm -f {} \;
    else
        find "${storage_dir}" -type f -name "${key}*${suffix}" -mtime +"${keep_day}" -exec rm -f {} \;
    fi

    return 0
}

do_action()
{
    local i database collection tarball_name
    local length="${#db_arr[@]}"
    local storage_dir="${dump_path}/${year}/${month}"
    for(( i = 0; i < "${length}"; i++ ));
    do
        database="${db_arr[$i]}"
        collection="${coll_arr[$i]}"
        keey_day="${keey_day_arr[$i]:-7}"
        keey_unit="${keey_unit_arr[$i]:-day}"
        tarball_name="${database}-${file_time_format}.tgz"
        log_file="${LOG_DIR}/${database}_${port}.${day}.log"

        # Dump
        do_dump "${host}" "${port}" "${user}" "${pass}" "${auth_db}" "${database}" "${collection}" "${storage_dir}"
        
        # Tarball
        do_tarball "${storage_dir}" "${database}" "${tarball_name}"
        
        # Rsync
        do_rsync "${storage_dir}" "${tarball_name}"

        # Clean
        do_clean_backup "${dump_path}" "${database}" "tgz" "${keey_day}" "${keey_unit}"
    done
}

cd "${PROJECT_ROOT}"
account_file=''
captcha=''
action='default'
parse_arguments $@
test "${PARA_NUM}" -lt 1 && usage
auto_load_conf "${account_file}"
check_accout_arg "${host}" "${port}" "${user}" "${pass}" "${auth_db}"
do_action

/usr/bin/find "${LOG_DIR}" -type f -mtime +30 -name "*.log" | xargs rm -f

exit 0
